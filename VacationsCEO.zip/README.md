Este ejecutable solo funciona en windows.


Tener el archivo couplesData.csv al mismo nivel que parejasCeo.exe

Cambiar las parejas de prueba en el csv y simplemente ejecutar parejasCeo.exe
El codigo fuente esta en main.go

Nota: extensiones .go se pueden abrir en cualquier editor de texto